package OnlineRadioDatabase.exeptions;

/**
 * Created by George-Lenovo on 7/8/2017.
 */
public class InvalidArtistNameException extends InvalidSongException{
    public InvalidArtistNameException(String message) {
        super(message);
    }
}
