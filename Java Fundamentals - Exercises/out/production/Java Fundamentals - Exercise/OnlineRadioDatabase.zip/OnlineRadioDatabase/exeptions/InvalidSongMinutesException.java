package OnlineRadioDatabase.exeptions;

/**
 * Created by George-Lenovo on 7/8/2017.
 */
public class InvalidSongMinutesException extends InvalidSongLengthException {

    public InvalidSongMinutesException(String message) {
        super(message);
    }
}
