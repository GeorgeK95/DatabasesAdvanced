package OnlineRadioDatabase.exeptions;

/**
 * Created by George-Lenovo on 7/8/2017.
 */
public class InvalidSongLengthException extends InvalidSongException {
    public InvalidSongLengthException(String message) {
        super(message);
    }
}
