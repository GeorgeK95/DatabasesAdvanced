package OnlineRadioDatabase;

import OnlineRadioDatabase.exeptions.InvalidSongException;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by George-Lenovo on 7/8/2017.
 */
public class Main {
    private static int totalHours = 0;
    private static int totalMinutes = 0;
    private static int totalSeconds = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = Integer.parseInt(in.nextLine());
        List<Song> songs = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String line = in.nextLine().trim();
            String[] spl = line.split(";");
            String[] time = spl[2].split(":");

            String artist = spl[0];
            String song = spl[1];
            int minutes = 0;
            int seconds = 0;

            try {
                minutes = Integer.parseInt(time[0]);
                seconds = Integer.parseInt(time[1]);
            } catch (NumberFormatException e) {
                System.out.println("Invalid song length.");
            }

            try {
                Song songObj = new Song(artist, song, minutes, seconds);
                songs.add(songObj);
                System.out.println("Song added.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        }

        System.out.println("Songs added: " + songs.size());

        setTotalTime(songs);
        System.out.printf("Playlist length: %dh %dm %ds", totalHours, totalMinutes, totalSeconds);
    }

    private static void setTotalTime(List<Song> songs) {
        int sec = songs.stream().mapToInt(Song::getSeconds).sum();
        int minToAdd = sec / 60;
        sec %= 60;

        int min = songs.stream().mapToInt(Song::getMinutes).sum();
        min += minToAdd;
        int hoursToAdd = min / 60;
        min %= 60;

        totalHours = hoursToAdd;
        totalMinutes = min;
        totalSeconds = sec;


    }

}
