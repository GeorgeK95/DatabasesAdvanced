/**
 * Created by George-Lenovo on 7/5/2017.
 */
public interface Car {
    public static int TIRES = 4;

    String getModel();

    String getColor();

    int getHorsePower();
}
