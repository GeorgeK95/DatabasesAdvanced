/**
 * Created by George-Lenovo on 7/5/2017.
 */
public interface Sellable extends Car{
    double getPrice();
}
