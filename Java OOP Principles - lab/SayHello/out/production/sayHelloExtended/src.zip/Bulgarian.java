/**
 * Created by George-Lenovo on 7/5/2017.
 */
public class Bulgarian extends BasePerson {
    private String name;

    public Bulgarian(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String sayHello() {
        return "Здравей";
    }
}
