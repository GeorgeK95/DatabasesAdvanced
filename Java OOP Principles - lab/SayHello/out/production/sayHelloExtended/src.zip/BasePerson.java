/**
 * Created by George-Lenovo on 7/5/2017.
 */
public abstract class BasePerson implements Person {
    private String name;


    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return this.name;
    }


}
