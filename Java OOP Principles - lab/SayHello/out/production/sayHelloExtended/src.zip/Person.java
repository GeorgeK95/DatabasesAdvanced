/**
 * Created by George-Lenovo on 7/5/2017.
 */
public interface Person {
    String getName();

    //    default String sayHello() {
//        return "Hello";
//    }
    String sayHello();
}
