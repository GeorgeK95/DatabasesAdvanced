/**
 * Created by George-Lenovo on 7/5/2017.
 */
public class European extends BasePerson{
    private String name;

    public European(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String sayHello() {
        return "Hello";
    }
}
